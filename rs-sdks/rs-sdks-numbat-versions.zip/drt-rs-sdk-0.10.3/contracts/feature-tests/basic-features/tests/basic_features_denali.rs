extern crate basic_features;
use basic_features::*;
use numbat_wasm::*;
use numbat_wasm_debug::*;

fn contract_map() -> ContractMap<TxContext> {
	let mut contract_map = ContractMap::new();
	contract_map.register_contract(
		"file:../output/basic-features.wasm",
		Box::new(|context| Box::new(BasicFeaturesImpl::new(context))),
	);
	contract_map
}

#[test]
fn block_info() {
	parse_execute_denali("denali/block_info.scen.json", &contract_map());
}

#[test]
fn boxed_bytes_zeros() {
	parse_execute_denali("denali/boxed_bytes_zeros.scen.json", &contract_map());
}

#[test]
fn count_ones() {
	parse_execute_denali("denali/count_ones.scen.json", &contract_map());
}

#[test]
fn echo_array_u8() {
	parse_execute_denali("denali/echo_array_u8.scen.json", &contract_map());
}

#[test]
fn echo_async_result_empty() {
	parse_execute_denali("denali/echo_async_result_empty.scen.json", &contract_map());
}

#[test]
fn echo_i32() {
	parse_execute_denali("denali/echo_i32.scen.json", &contract_map());
}

#[test]
fn echo_i64() {
	parse_execute_denali("denali/echo_i64.scen.json", &contract_map());
}

#[test]
fn echo_multi_i32() {
	parse_execute_denali("denali/echo_multi_i32.scen.json", &contract_map());
}

#[test]
fn echo_nothing() {
	parse_execute_denali("denali/echo_nothing.scen.json", &contract_map());
}

#[test]
fn echo_u64() {
	parse_execute_denali("denali/echo_u64.scen.json", &contract_map());
}

#[test]
fn echo_usize() {
	parse_execute_denali("denali/echo_usize.scen.json", &contract_map());
}

#[test]
fn echo_varags_tuples() {
	parse_execute_denali("denali/echo_varags_tuples.scen.json", &contract_map());
}

#[test]
fn echo_varargs_u32() {
	parse_execute_denali("denali/echo_varargs_u32.scen.json", &contract_map());
}

#[test]
fn echo_slice_u8() {
	parse_execute_denali("denali/echo_slice_u8.scen.json", &contract_map());
}

#[test]
fn echo_string() {
	parse_execute_denali("denali/echo_string.scen.json", &contract_map());
}

#[test]
fn echo_str() {
	parse_execute_denali("denali/echo_str.scen.json", &contract_map());
}

#[test]
fn echo_str_box() {
	parse_execute_denali("denali/echo_str_box.scen.json", &contract_map());
}

#[test]
fn echo_vec_u8() {
	parse_execute_denali("denali/echo_vec_u8.scen.json", &contract_map());
}

#[test]
fn echo_boxed_bytes() {
	parse_execute_denali("denali/echo_boxed_bytes.scen.json", &contract_map());
}

#[test]
fn panic() {
	parse_execute_denali("denali/panic.scen.json", &contract_map());
}

#[test]
fn return_error() {
	parse_execute_denali("denali/return_error.scen.json", &contract_map());
}

#[test]
fn storage_addr() {
	parse_execute_denali("denali/storage_addr.scen.json", &contract_map());
}

#[test]
fn storage_big_int() {
	parse_execute_denali("denali/storage_big_int.scen.json", &contract_map());
}

#[test]
fn storage_big_uint() {
	parse_execute_denali("denali/storage_big_uint.scen.json", &contract_map());
}

#[test]
fn storage_bool() {
	parse_execute_denali("denali/storage_bool.scen.json", &contract_map());
}

#[test]
fn storage_i64() {
	parse_execute_denali("denali/storage_i64.scen.json", &contract_map());
}

#[test]
fn storage_i64_bad() {
	parse_execute_denali("denali/storage_i64_bad.scen.json", &contract_map());
}

#[test]
fn storage_map1() {
	parse_execute_denali("denali/storage_map1.scen.json", &contract_map());
}

#[test]
fn storage_map2() {
	parse_execute_denali("denali/storage_map2.scen.json", &contract_map());
}

#[test]
fn storage_map3() {
	parse_execute_denali("denali/storage_map3.scen.json", &contract_map());
}

#[test]
fn storage_opt_addr() {
	parse_execute_denali("denali/storage_opt_addr.scen.json", &contract_map());
}

#[test]
fn storage_clear() {
	parse_execute_denali("denali/storage_clear.scen.json", &contract_map());
}

#[test]
fn storage_reserved() {
	parse_execute_denali("denali/storage_reserved.scen.json", &contract_map());
}

#[test]
fn storage_u64() {
	parse_execute_denali("denali/storage_u64.scen.json", &contract_map());
}

#[test]
fn storage_u64_bad() {
	parse_execute_denali("denali/storage_u64_bad.scen.json", &contract_map());
}

#[test]
fn storage_usize() {
	parse_execute_denali("denali/storage_usize.scen.json", &contract_map());
}

#[test]
fn storage_usize_bad() {
	parse_execute_denali("denali/storage_usize_bad.scen.json", &contract_map());
}

#[test]
fn storage_vec_u8() {
	parse_execute_denali("denali/storage_vec_u8.scen.json", &contract_map());
}
