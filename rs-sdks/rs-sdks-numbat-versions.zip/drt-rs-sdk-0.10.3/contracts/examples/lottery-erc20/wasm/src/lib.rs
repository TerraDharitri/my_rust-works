#![no_std]

pub use lottery_erc20::*;
pub use numbat_wasm_output::*;
