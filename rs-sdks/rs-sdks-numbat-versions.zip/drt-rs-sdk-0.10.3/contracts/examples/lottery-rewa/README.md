# Interaction

Deploy & interact with contract:

```
cd contracts/examples/lottery-rewa/interaction
npx ts-node ./playground.ts
```
