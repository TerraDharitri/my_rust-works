#![no_std]

pub use factorial::*;
pub use numbat_wasm_output::*;
