#![no_std]

pub use simple_erc20::*;
pub use numbat_wasm_output::*;
