#![no_std]

pub use non_fungible_tokens::*;
pub use numbat_wasm_output::*;
