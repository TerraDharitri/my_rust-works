# Numbat smart contract module for managing a list of users

This is a standard smart contract module, that when added to a smart contract manages a list of users.

It provides a bi-directional map:
* from user address to a unique user id
* from user id to address
