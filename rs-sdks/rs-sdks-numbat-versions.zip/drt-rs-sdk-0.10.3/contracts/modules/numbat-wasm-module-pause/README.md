# Numbat smart contract module for adding a global pause flag

This is a standard smart contract module, that when added to a smart contract offers pausability.

It offers:
* an endpoint where the owner can pause/unpause contract
* a method to check if contract is paused or not
