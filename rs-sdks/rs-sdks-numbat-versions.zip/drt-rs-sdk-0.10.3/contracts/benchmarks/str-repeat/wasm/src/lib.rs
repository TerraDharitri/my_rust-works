#![no_std]

pub use str_repeat::*;
pub use numbat_wasm_output::*;
