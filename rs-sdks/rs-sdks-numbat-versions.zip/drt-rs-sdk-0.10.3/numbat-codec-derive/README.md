# numbat-codec-derive

Crate that contains all macro code generation the numbat-codec serializer.

There are 4 derive macros currently provided:
* NestedEncode
* NestedDecode
* TopEncode
* TopDecode

For more info about the serialization format, see [the developer reference](https://docs.numbat.com/developers/developer-reference/numbat-serialization-format/).
