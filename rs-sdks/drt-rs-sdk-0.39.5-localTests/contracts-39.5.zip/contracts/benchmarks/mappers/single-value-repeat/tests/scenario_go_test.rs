#[test]
fn single_value_repeat_struct_go() {
    dharitri_sc_scenario::run_go("scenarios/single_value_repeat_struct.scen.json");
}

#[test]
fn single_value_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/single_value_repeat.scen.json");
}
