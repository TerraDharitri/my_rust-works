#[test]
fn queue_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/queue_repeat.scen.json");
}
