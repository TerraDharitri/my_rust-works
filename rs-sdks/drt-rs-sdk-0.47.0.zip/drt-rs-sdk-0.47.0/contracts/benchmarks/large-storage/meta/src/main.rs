fn main() {
    dharitri_sc_meta::cli_main::<large_storage::AbiProvider>();
}
