pub mod curve_function;
pub mod linear_function;
