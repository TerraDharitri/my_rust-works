fn main() {
    dharitri_sc_meta_lib::cli_main::<rewards_distribution::AbiProvider>();
}
