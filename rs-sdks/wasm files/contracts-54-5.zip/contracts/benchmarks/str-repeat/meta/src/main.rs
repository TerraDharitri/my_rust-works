fn main() {
    dharitri_sc_meta_lib::cli_main::<str_repeat::AbiProvider>();
}
