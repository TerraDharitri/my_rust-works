# Ping pong dapp example

## Prerequisites
- trunk

```bash
cargo install trunk
```
Run this example locally with `trunk serve --open`.