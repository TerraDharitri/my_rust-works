fn main() {
    dharitri_sc_meta_lib::cli_main::<map_repeat::AbiProvider>();
}
