fn main() {
    dharitri_sc_meta::cli_main::<crowdfunding_dcdt::AbiProvider>();
}
