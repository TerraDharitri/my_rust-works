fn main() {
    dharitri_sc_meta_lib::cli_main::<dharitri_sc_wrewa_swap::AbiProvider>();
}
