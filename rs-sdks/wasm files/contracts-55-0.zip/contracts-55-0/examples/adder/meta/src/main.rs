fn main() {
    dharitri_sc_meta_lib::cli_main::<adder::AbiProvider>();
}
