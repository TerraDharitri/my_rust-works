
use dharitri_sc_snippets::imports::*;
use rust_interact::adder_cli;

#[tokio::main]
async fn main() {
    adder_cli().await;
}  

