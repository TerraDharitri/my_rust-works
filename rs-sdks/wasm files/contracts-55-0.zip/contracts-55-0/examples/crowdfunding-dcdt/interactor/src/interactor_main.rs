
use dharitri_sc_snippets::imports::*;
use rust_interact::crowdfunding_dcdt_cli;

#[tokio::main]
async fn main() {
    crowdfunding_dcdt_cli().await;
}  

