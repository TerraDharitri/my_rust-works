
use dharitri_sc_snippets::imports::*;
use rust_interact::check_pause_cli;

#[tokio::main]
async fn main() {
    check_pause_cli().await;
}  

