
use dharitri_sc_snippets::imports::*;
use rust_interact::kitty_auction_cli;

#[tokio::main]
async fn main() {
    kitty_auction_cli().await;
}  

