
use dharitri_sc_snippets::imports::*;
use rust_interact::bonding_curve_contract_cli;

#[tokio::main]
async fn main() {
    bonding_curve_contract_cli().await;
}  

