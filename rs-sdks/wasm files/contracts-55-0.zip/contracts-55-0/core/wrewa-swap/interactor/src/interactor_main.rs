
use dharitri_sc_snippets::imports::*;
use rust_interact::dharitri_sc_wrewa_swap_cli;

#[tokio::main]
async fn main() {
    dharitri_sc_wrewa_swap_cli().await;
}  

