
use dharitri_sc_snippets::imports::*;
use rust_interact::dharitri_sc_price_aggregator_cli;

#[tokio::main]
async fn main() {
    dharitri_sc_price_aggregator_cli().await;
}  

