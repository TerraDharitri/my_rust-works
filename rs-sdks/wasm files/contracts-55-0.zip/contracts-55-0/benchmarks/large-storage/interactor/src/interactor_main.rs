
use dharitri_sc_snippets::imports::*;
use rust_interact::large_storage_cli;

#[tokio::main]
async fn main() {
    large_storage_cli().await;
}  

