
use dharitri_sc_snippets::imports::*;
use rust_interact::set_repeat_cli;

#[tokio::main]
async fn main() {
    set_repeat_cli().await;
}  

