
use dharitri_sc_snippets::imports::*;
use rust_interact::queue_repeat_cli;

#[tokio::main]
async fn main() {
    queue_repeat_cli().await;
}  

