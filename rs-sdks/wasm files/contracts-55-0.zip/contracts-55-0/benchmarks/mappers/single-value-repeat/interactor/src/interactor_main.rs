
use dharitri_sc_snippets::imports::*;
use rust_interact::single_value_repeat_cli;

#[tokio::main]
async fn main() {
    single_value_repeat_cli().await;
}  

