
use dharitri_sc_snippets::imports::*;
use rust_interact::vec_repeat_cli;

#[tokio::main]
async fn main() {
    vec_repeat_cli().await;
}  

