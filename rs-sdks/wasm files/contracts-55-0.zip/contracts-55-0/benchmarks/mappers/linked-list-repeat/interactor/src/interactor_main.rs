
use dharitri_sc_snippets::imports::*;
use rust_interact::linked_list_repeat_cli;

#[tokio::main]
async fn main() {
    linked_list_repeat_cli().await;
}  

