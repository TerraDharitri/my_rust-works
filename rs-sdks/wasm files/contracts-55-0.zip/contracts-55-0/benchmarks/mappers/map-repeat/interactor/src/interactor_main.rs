
use dharitri_sc_snippets::imports::*;
use rust_interact::map_repeat_cli;

#[tokio::main]
async fn main() {
    map_repeat_cli().await;
}  

