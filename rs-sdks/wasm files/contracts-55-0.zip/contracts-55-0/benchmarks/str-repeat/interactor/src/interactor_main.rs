
use dharitri_sc_snippets::imports::*;
use rust_interact::str_repeat_cli;

#[tokio::main]
async fn main() {
    str_repeat_cli().await;
}  

