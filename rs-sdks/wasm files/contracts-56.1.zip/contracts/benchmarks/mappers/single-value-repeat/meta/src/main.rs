fn main() {
    dharitri_sc_meta_lib::cli_main::<single_value_repeat::AbiProvider>();
}
