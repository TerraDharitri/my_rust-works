fn main() {
    dharitri_sc_meta::cli_main::<dharitri_sc_wrewa_swap::AbiProvider>();
}
