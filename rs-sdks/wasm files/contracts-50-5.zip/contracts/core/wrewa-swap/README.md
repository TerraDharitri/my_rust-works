# REWA-WREWA swap

## Overview

The REWA-WREWA swap contract mints and distributes the WREWA token, in equal amount to the amount of REWA locked in the contract.

There are such contracts deployed in each shard.
