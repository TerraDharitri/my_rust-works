fn main() {
    dharitri_sc_meta::cli_main::<linked_list_repeat::AbiProvider>();
}
