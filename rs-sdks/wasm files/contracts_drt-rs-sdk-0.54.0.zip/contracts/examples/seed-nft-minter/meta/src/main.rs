fn main() {
    dharitri_sc_meta_lib::cli_main::<seed_nft_minter::AbiProvider>();
}
