fn main() {
    dharitri_sc_meta_lib::cli_main::<dcdt_transfer_with_fee::AbiProvider>();
}
