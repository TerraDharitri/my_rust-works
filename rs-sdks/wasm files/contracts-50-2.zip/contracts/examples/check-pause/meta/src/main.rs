fn main() {
    dharitri_sc_meta::cli_main::<check_pause::AbiProvider>();
}
