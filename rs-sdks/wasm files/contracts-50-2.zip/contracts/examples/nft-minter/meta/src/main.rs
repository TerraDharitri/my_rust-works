fn main() {
    dharitri_sc_meta::cli_main::<nft_minter::AbiProvider>();
}
