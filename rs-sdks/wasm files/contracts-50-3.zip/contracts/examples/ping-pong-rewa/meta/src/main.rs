fn main() {
    dharitri_sc_meta::cli_main::<ping_pong_rewa::AbiProvider>();
}
