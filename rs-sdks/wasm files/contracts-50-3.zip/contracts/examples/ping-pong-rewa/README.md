# PingPong

`PingPong` is a simple Smart Contract.
