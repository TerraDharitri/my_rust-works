#[test]
fn pause_go() {
    dharitri_sc_scenario::run_go("scenarios/pause-and-unpause.scen.json");
}
