fn main() {
    dharitri_sc_meta::cli_main::<seed_nft_minter::AbiProvider>();
}
