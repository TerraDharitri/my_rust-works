#[test]
fn str_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/str_repeat.scen.json");
}
