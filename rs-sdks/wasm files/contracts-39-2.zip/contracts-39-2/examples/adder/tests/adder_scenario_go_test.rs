#[test]
fn adder_go() {
    dharitri_sc_scenario::run_go("scenarios/adder.scen.json");
}
