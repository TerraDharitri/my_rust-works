#[test]
fn empty_go() {
    dharitri_sc_scenario::run_go("scenarios/empty.scen.json");
}
