#[test]
fn large_storage_go() {
    dharitri_sc_scenario::run_go("scenarios/large_storage.scen.json");
}
