#[test]
fn send_tx_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/send_tx_repeat.scen.json");
}
