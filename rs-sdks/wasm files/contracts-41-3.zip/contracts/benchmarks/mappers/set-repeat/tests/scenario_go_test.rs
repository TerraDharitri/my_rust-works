#[test]
fn set_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/set_repeat.scen.json");
}

#[test]
fn set_repeat_struct_go() {
    dharitri_sc_scenario::run_go("scenarios/set_repeat_struct.scen.json");
}
