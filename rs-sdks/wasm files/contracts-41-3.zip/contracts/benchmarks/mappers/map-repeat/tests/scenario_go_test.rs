#[test]
fn map_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/map_repeat.scen.json");
}

#[test]
fn map_repeat_struct_go() {
    dharitri_sc_scenario::run_go("scenarios/map_repeat_struct.scen.json");
}
