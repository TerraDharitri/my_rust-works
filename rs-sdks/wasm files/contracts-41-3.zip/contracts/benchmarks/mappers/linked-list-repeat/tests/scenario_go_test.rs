#[test]
fn linked_list_repeat_go() {
    dharitri_sc_scenario::run_go("scenarios/linked_list_repeat.scen.json");
}

#[test]
fn linked_list_repeat_struct_go() {
    dharitri_sc_scenario::run_go("scenarios/linked_list_repeat_struct.scen.json");
}
