fn main() {
    dharitri_sc_meta_lib::cli_main::<send_tx_repeat::AbiProvider>();
}
