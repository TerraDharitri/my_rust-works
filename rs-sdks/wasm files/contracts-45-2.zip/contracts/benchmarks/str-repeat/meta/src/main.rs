fn main() {
    dharitri_sc_meta::cli_main::<str_repeat::AbiProvider>();
}
