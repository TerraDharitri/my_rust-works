fn main() {
    dharitri_sc_meta::cli_main::<dharitri_sc_price_aggregator::AbiProvider>();
}
