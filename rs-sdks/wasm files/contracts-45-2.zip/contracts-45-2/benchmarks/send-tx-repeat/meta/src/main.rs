fn main() {
    dharitri_sc_meta::cli_main::<send_tx_repeat::AbiProvider>();
}
