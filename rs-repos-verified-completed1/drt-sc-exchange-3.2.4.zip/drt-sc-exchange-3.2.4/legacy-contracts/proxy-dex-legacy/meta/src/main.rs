fn main() {
    dharitri_sc_meta_lib::cli_main::<proxy_dex_legacy::AbiProvider>();
}