fn main() {
    dharitri_sc_meta::cli_main::<dns::AbiProvider>();
}
