fn main() {
    dharitri_sc_meta::cli_main::<dharitri_price_aggregator_sc::AbiProvider>();
}
