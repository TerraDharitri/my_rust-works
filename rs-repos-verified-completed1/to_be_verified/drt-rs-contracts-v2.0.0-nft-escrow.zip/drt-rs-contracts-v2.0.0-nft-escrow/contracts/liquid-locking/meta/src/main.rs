fn main() {
    dharitri_sc_meta::cli_main::<liquid_locking::AbiProvider>();
}
