fn main() {
    dharitri_sc_meta_lib::cli_main::<launchpad_locked_tokens_and_guaranteed_tickets::AbiProvider>(
    );
}
