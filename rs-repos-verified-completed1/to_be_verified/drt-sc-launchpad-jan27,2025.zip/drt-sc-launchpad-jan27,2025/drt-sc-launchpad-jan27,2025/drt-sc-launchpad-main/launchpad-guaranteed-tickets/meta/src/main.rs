fn main() {
    dharitri_sc_meta_lib::cli_main::<launchpad_guaranteed_tickets::AbiProvider>();
}
