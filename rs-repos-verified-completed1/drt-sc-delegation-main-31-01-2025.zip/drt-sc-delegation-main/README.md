# Smart contract for the legacy delegation

The delegation contract holds and stakes delegators' funds to the Dharitri Community Nodes. 
