# CTF Bump

Let's see who can bump the most!

Participants are asked to call `bump` as many times as possible. Each `bump` increases the score by one.

It is also possible to donate your bumps, if you're feeling generous (or if you used a smart contract to harvest more bumps).
