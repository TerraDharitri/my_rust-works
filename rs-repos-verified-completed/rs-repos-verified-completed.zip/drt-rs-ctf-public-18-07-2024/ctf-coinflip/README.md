# CTF Coinflip

Let's see who can get the highest score!

The rules are as follows:
- You call coinflip.
- The contract flips a coin, your odds of being lucky are 50/50.
- If you are lucky, you get 1 point.
- If you are unlucky, your score is reset to zero.

You can rely on sheer brute-force, but some of you will notice that the "randomness" function is not exactly bulletproof.

Best of _"luck"_!
