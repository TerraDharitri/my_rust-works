
use dharitri_sc_snippets::imports::*;
use rust_interact::delegation_latest_cli;

#[tokio::main]
async fn main() {
    delegation_latest_cli().await;
}  

