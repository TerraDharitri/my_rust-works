#![no_std]
#![allow(clippy::string_lit_as_bytes)]
#![allow(clippy::type_complexity)]

// auxiliaries
pub mod types;

// modules
pub mod node_config;
