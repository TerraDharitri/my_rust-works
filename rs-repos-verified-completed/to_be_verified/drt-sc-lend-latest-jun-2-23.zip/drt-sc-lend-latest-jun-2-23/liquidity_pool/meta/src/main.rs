fn main() {
    dharitri_sc_meta::cli_main::<liquidity_pool::AbiProvider>();
}
