fn main() {
    dharitri_sc_meta::cli_main::<safety_module::AbiProvider>();
}
