fn main() {
    dharitri_sc_meta::cli_main::<lending_pool::AbiProvider>();
}
