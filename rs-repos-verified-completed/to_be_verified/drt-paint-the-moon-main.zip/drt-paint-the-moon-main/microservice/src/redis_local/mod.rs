mod data;

pub use data::Redis;
