fn main() {
    numbat_wasm_debug::meta::perform::<seller_contract_mock::AbiProvider>();
}
