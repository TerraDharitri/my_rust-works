fn main() {
    numbat_wasm_debug::meta::perform::<dcdt_nft_marketplace::AbiProvider>();
}
