/*
#[test]
fn auction_end_deadline_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_end_deadline.scen.json", &contract_map());
}

#[test]
fn auction_end_max_bid_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_end_max_bid.scen.json", &contract_map());
}

#[test]
fn auction_sell_all_end_deadline_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_sell_all_end_deadline.scen.json", &contract_map());
}

#[test]
fn auction_sell_one_by_one_end_deadline_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_sell_one_by_one_end_deadline.scen.json", &contract_map());
}

#[test]
fn auction_sft_sell_all_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_sft_sell_all.scen.json", &contract_map());
}

#[test]
fn auction_sft_sell_one_by_one_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_sft_sell_one_by_one.scen.json", &contract_map());
}

#[test]
fn auction_token_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_token.scen.json", &contract_map());
}

#[test]
fn auction_with_start_time_rs() {
    numbat_wasm_debug::denali_rs("denali/auction_with_start_time.scen.json", &contract_map());
}

#[test]
fn bid_first_rs() {
    numbat_wasm_debug::denali_rs("denali/bid_first.scen.json", &contract_map());
}

#[test]
fn bid_max_rs() {
    numbat_wasm_debug::denali_rs("denali/bid_max.scen.json", &contract_map());
}

#[test]
fn bid_second_rs() {
    numbat_wasm_debug::denali_rs("denali/bid_second.scen.json", &contract_map());
}

#[test]
fn bid_sft_sell_all_first_rs() {
    numbat_wasm_debug::denali_rs("denali/bid_sft_sell_all_first.scen.json", &contract_map());
}

#[test]
fn bid_sft_sell_all_second_rs() {
    numbat_wasm_debug::denali_rs("denali/bid_sft_sell_all_second.scen.json", &contract_map());
}

#[test]
fn buy_sft_sell_one_by_one_rs() {
    numbat_wasm_debug::denali_rs("denali/buy_sft_sell_one_by_one.scen.json", &contract_map());
}

#[test]
fn buy_sft_sell_one_by_one_second_rs() {
    numbat_wasm_debug::denali_rs("denali/buy_sft_sell_one_by_one_second.scen.json", &contract_map());
}

#[test]
fn init_rs() {
    numbat_wasm_debug::denali_rs("denali/init.scen.json", &contract_map());
}

#[test]
fn invalid_bids_rs() {
    numbat_wasm_debug::denali_rs("denali/invalid_bids.scen.json", &contract_map());
}

#[test]
fn specific_token_auctioned_rs() {
    numbat_wasm_debug::denali_rs("denali/specific_token_auctioned.scen.json", &contract_map());
}

#[test]
fn view_functions_rs() {
    numbat_wasm_debug::denali_rs("denali/view_functions.scen.json", &contract_map());
}

#[test]
fn withdraw_rs() {
    numbat_wasm_debug::denali_rs("denali/withdraw.scen.json", &contract_map());
}

#[test]
fn withdraw_after_end_auction_rs() {
    numbat_wasm_debug::denali_rs("denali/withdraw_after_end_auction.scen.json", &contract_map());
}
*/
