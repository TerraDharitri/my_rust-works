fn main() {
    numbat_wasm_debug::abi_json::print_abi::<stablecoin_v2::AbiProvider>();
}
