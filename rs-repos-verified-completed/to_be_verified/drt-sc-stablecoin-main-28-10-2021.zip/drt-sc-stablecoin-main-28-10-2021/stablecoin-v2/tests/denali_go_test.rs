/*
#[test]
fn unwrap_rewa_go() {
    numbat_wasm_debug::denali_go("denali/.scen.json");
}
*/
