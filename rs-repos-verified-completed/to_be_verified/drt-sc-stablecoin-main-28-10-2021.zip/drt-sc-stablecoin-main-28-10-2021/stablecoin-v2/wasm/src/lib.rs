#![no_std]

pub use stablecoin_v2::*;
pub use numbat_wasm_output::*;
