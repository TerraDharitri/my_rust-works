use liquid_locking::*;
use dharitri_sc::types::{
    BigUint, DcdtTokenPayment, ManagedVec, TestAddress, TestDcdtTransfer, TestSCAddress,
    TestTokenIdentifier, TokenIdentifier,
};
use dharitri_sc_scenario::{
    api::StaticApi, imports::DrtscPath, ExpectError, ScenarioTxRun, ScenarioWorld,
};

const OWNER_ADDRESS: TestAddress = TestAddress::new("owner");
const LIQUID_STAKING_ADDRESS: TestSCAddress = TestSCAddress::new("liquid-locking");
const CODE_PATH: DrtscPath = DrtscPath::new("output/liquid-locking.drtsc.json");
const FIRST_USER_ADDRESS: TestAddress = TestAddress::new("user1");
const SECOND_USER_ADDRESS: TestAddress = TestAddress::new("user2");
const WHITELIST_TOKEN_1: TestTokenIdentifier = TestTokenIdentifier::new("AAA-111111");
const WHITELIST_TOKEN_2: TestTokenIdentifier = TestTokenIdentifier::new("BBB-222222");
const BLACKLIST_TOKEN: TestTokenIdentifier = TestTokenIdentifier::new("CCC-333333");

fn world() -> ScenarioWorld {
    let mut blockchain = ScenarioWorld::new();

    blockchain.set_current_dir_from_workspace("contracts/liquid-locking");
    blockchain.register_contract(CODE_PATH, liquid_locking::ContractBuilder);
    blockchain
}

#[test]
fn test() {
    let mut world = world();

    world
        .account(OWNER_ADDRESS)
        .nonce(1)
        .new_address(OWNER_ADDRESS, 1, LIQUID_STAKING_ADDRESS);

    // setup user accounts

    world
        .account(FIRST_USER_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_1, 1000)
        .dcdt_balance(WHITELIST_TOKEN_2, 1000);

    world
        .account(SECOND_USER_ADDRESS)
        .balance(1_000_000_000)
        .dcdt_balance(BLACKLIST_TOKEN, 1000)
        .dcdt_balance(WHITELIST_TOKEN_2, 1000);

    // deploy

    world
        .tx()
        .from(OWNER_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .init(10u64)
        .code(CODE_PATH)
        .new_address(LIQUID_STAKING_ADDRESS)
        .run();

    world.check_account(OWNER_ADDRESS);
    world
        .check_account(LIQUID_STAKING_ADDRESS)
        .check_storage("str:unbond_period", "10");

    // whitelist tokens

    world
        .tx()
        .from(OWNER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .whitelist_token(WHITELIST_TOKEN_1)
        .run();

    world
        .tx()
        .from(OWNER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .whitelist_token(WHITELIST_TOKEN_2)
        .run();

    world.check_account(OWNER_ADDRESS);
    world
        .check_account(FIRST_USER_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_1, 1000)
        .dcdt_balance(WHITELIST_TOKEN_2, 1000);
    world
        .check_account(SECOND_USER_ADDRESS)
        .balance(1_000_000_000)
        .dcdt_balance(BLACKLIST_TOKEN, 1000)
        .dcdt_balance(WHITELIST_TOKEN_2, 1000);

    world
        .check_account(LIQUID_STAKING_ADDRESS)
        .check_storage("str:unbond_period", "10")
        .check_storage("str:token_whitelist.len", "2")
        .check_storage("str:token_whitelist.item|u32:1", "str:AAA-111111")
        .check_storage("str:token_whitelist.item|u32:2", "str:BBB-222222")
        .check_storage("str:token_whitelist.index|nested:str:AAA-111111", "1")
        .check_storage("str:token_whitelist.index|nested:str:BBB-222222", "2");

    // lock fail

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .dcdt(TestDcdtTransfer(BLACKLIST_TOKEN, 0u64, 500u64))
        .with_result(ExpectError(4, "token is not whitelisted"))
        .run();

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .rewa(1_000_000)
        .with_result(ExpectError(4, "no payment provided"))
        .run();

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .with_result(ExpectError(4, "no payment provided"))
        .run();

    // lock success

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .dcdt(TestDcdtTransfer(WHITELIST_TOKEN_2, 0, 500))
        .run();

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .dcdt(TestDcdtTransfer(WHITELIST_TOKEN_2, 0, 500))
        .run();

    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .dcdt(TestDcdtTransfer(WHITELIST_TOKEN_1, 0, 1000))
        .run();

    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .lock()
        .dcdt(TestDcdtTransfer(WHITELIST_TOKEN_2, 0, 1000))
        .run();

    world.check_account(OWNER_ADDRESS);
    world.check_account(FIRST_USER_ADDRESS);
    world
        .check_account(SECOND_USER_ADDRESS)
        .dcdt_balance(BLACKLIST_TOKEN, 1000)
        .balance(1_000_000_000);
    world
        .check_account(LIQUID_STAKING_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_1, 1000)
        .dcdt_balance(WHITELIST_TOKEN_2, 2000)
        .check_storage("str:unbond_period", "10")
        .check_storage("str:token_whitelist.len", "2")
        .check_storage("str:token_whitelist.item|u32:1", "str:AAA-111111")
        .check_storage("str:token_whitelist.item|u32:2", "str:BBB-222222")
        .check_storage("str:token_whitelist.index|nested:str:AAA-111111", "1")
        .check_storage("str:token_whitelist.index|nested:str:BBB-222222", "2")
        .check_storage("str:locked_tokens|address:user2|str:.len", "1")
        .check_storage(
            "str:locked_tokens|address:user2|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user2|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage(
            "str:locked_token_amounts|address:user2|nested:str:BBB-222222",
            "1000",
        )
        .check_storage("str:locked_tokens|address:user1|str:.len", "2")
        .check_storage(
            "str:locked_tokens|address:user1|str:.item|u32:1",
            "str:AAA-111111",
        )
        .check_storage(
            "str:locked_tokens|address:user1|str:.item|u32:2",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user1|str:.index|nested:str:AAA-111111",
            "1",
        )
        .check_storage(
            "str:locked_tokens|address:user1|str:.index|nested:str:BBB-222222",
            "2",
        )
        .check_storage(
            "str:locked_token_amounts|address:user1|nested:str:AAA-111111",
            "1000",
        )
        .check_storage(
            "str:locked_token_amounts|address:user1|nested:str:BBB-222222",
            "1000",
        );

    // unstake fail

    let mut unlock_single_dcdt = ManagedVec::<StaticApi, DcdtTokenPayment<StaticApi>>::new();
    let mut unlock_multiple_dcdt = ManagedVec::<StaticApi, DcdtTokenPayment<StaticApi>>::new();

    unlock_single_dcdt.push(DcdtTokenPayment {
        token_identifier: BLACKLIST_TOKEN.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::from(1500u64),
    });
    unlock_multiple_dcdt.push(DcdtTokenPayment {
        token_identifier: WHITELIST_TOKEN_1.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::zero(),
    });
    unlock_multiple_dcdt.push(DcdtTokenPayment {
        token_identifier: WHITELIST_TOKEN_1.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::from(300u64),
    });

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_single_dcdt)
        .with_result(ExpectError(4, "unavailable amount"))
        .run();

    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_multiple_dcdt)
        .with_result(ExpectError(4, "requested amount cannot be 0"))
        .run();

    // unlock success

    unlock_single_dcdt = ManagedVec::<StaticApi, DcdtTokenPayment<StaticApi>>::new();
    unlock_multiple_dcdt = ManagedVec::<StaticApi, DcdtTokenPayment<StaticApi>>::new();

    unlock_single_dcdt.push(DcdtTokenPayment {
        token_identifier: WHITELIST_TOKEN_2.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::from(200u64),
    });
    unlock_multiple_dcdt.push(DcdtTokenPayment {
        token_identifier: WHITELIST_TOKEN_1.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::from(1000u64),
    });
    unlock_multiple_dcdt.push(DcdtTokenPayment {
        token_identifier: WHITELIST_TOKEN_2.to_token_identifier(),
        token_nonce: 0,
        amount: BigUint::from(300u64),
    });
    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_single_dcdt.clone())
        .run();

    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_multiple_dcdt)
        .run();

    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_single_dcdt.clone())
        .run();

    world.current_block().block_epoch(8);
    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unlock(unlock_single_dcdt)
        .run();

    world.check_account(OWNER_ADDRESS);
    world.check_account(FIRST_USER_ADDRESS);
    world
        .check_account(SECOND_USER_ADDRESS)
        .dcdt_balance(BLACKLIST_TOKEN, 1000)
        .balance(1_000_000_000);
    world
        .check_account(LIQUID_STAKING_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_1, 1_000u64)
        .dcdt_balance(WHITELIST_TOKEN_2, 2_000u64)
        .check_storage("str:unbond_period", "10")
        .check_storage("str:token_whitelist.len", "2")
        .check_storage("str:token_whitelist.item|u32:1", "str:AAA-111111")
        .check_storage("str:token_whitelist.item|u32:2", "str:BBB-222222")
        .check_storage("str:token_whitelist.index|nested:str:AAA-111111", "1")
        .check_storage("str:token_whitelist.index|nested:str:BBB-222222", "2")
        .check_storage("str:locked_tokens|address:user2|str:.len", "1")
        .check_storage(
            "str:locked_tokens|address:user2|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user2|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage(
            "str:locked_token_amounts|address:user2|nested:str:BBB-222222",
            "800",
        )
        .check_storage("str:locked_tokens|address:user1|str:.len", "1")
        .check_storage(
            "str:locked_tokens|address:user1|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user1|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage(
            "str:locked_token_amounts|address:user1|nested:str:BBB-222222",
            "300",
        )
        .check_storage("str:unlocked_tokens|address:user2|str:.len", "1")
        .check_storage(
            "str:unlocked_tokens|address:user2|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:unlocked_tokens|address:user2|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage("str:unlocked_tokens|address:user1|str:.len", "2")
        .check_storage(
            "str:unlocked_tokens|address:user1|str:.item|u32:1",
            "str:AAA-111111",
        )
        .check_storage(
            "str:unlocked_tokens|address:user1|str:.item|u32:2",
            "str:BBB-222222",
        )
        .check_storage(
            "str:unlocked_tokens|address:user1|str:.index|nested:str:AAA-111111",
            "1",
        )
        .check_storage(
            "str:unlocked_tokens|address:user1|str:.index|nested:str:BBB-222222",
            "2",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:BBB-222222|str:.len",
            "2",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:BBB-222222|str:.item|u32:1",
            "10",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:BBB-222222|str:.item|u32:2",
            "18",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:BBB-222222|str:.index|u64:10",
            "1",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:BBB-222222|str:.index|u64:18",
            "2",
        )
        .check_storage(
            "str:unlocked_token_amounts|address:user1|nested:str:BBB-222222|u64:10",
            "500",
        )
        .check_storage(
            "str:unlocked_token_amounts|address:user1|nested:str:BBB-222222|u64:18",
            "200",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:AAA-111111|str:.len",
            "1",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:AAA-111111|str:.item|u32:1",
            "10",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user1|nested:str:AAA-111111|str:.index|u64:10",
            "1",
        )
        .check_storage(
            "str:unlocked_token_amounts|address:user1|nested:str:AAA-111111|u64:10",
            "1000",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user2|nested:str:BBB-222222|str:.len",
            "1",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user2|nested:str:BBB-222222|str:.item|u32:1",
            "10",
        )
        .check_storage(
            "str:unlocked_token_epochs|address:user2|nested:str:BBB-222222|str:.index|u64:10",
            "1",
        )
        .check_storage(
            "str:unlocked_token_amounts|address:user2|nested:str:BBB-222222|u64:10",
            "200",
        );

    // unbond fail

    let mut unbond_tokens = ManagedVec::<StaticApi, TokenIdentifier<StaticApi>>::new();
    unbond_tokens.push(BLACKLIST_TOKEN.to_token_identifier());
    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unbond(unbond_tokens)
        .with_result(ExpectError(4, "nothing to unbond"))
        .run();

    unbond_tokens = ManagedVec::<StaticApi, TokenIdentifier<StaticApi>>::new();
    unbond_tokens.push(WHITELIST_TOKEN_2.to_token_identifier());
    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unbond(unbond_tokens)
        .with_result(ExpectError(4, "nothing to unbond"))
        .run();

    // unbond success

    unbond_tokens = ManagedVec::<StaticApi, TokenIdentifier<StaticApi>>::new();
    unbond_tokens.push(WHITELIST_TOKEN_2.to_token_identifier());
    world.current_block().block_epoch(11);
    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unbond(unbond_tokens)
        .run();

    unbond_tokens = ManagedVec::<StaticApi, TokenIdentifier<StaticApi>>::new();
    unbond_tokens.push(WHITELIST_TOKEN_2.to_token_identifier());
    world.current_block().block_epoch(22);
    world
        .tx()
        .from(SECOND_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unbond(unbond_tokens)
        .run();

    unbond_tokens = ManagedVec::<StaticApi, TokenIdentifier<StaticApi>>::new();
    unbond_tokens.push(WHITELIST_TOKEN_2.to_token_identifier());
    unbond_tokens.push(WHITELIST_TOKEN_1.to_token_identifier());
    world
        .tx()
        .from(FIRST_USER_ADDRESS)
        .to(LIQUID_STAKING_ADDRESS)
        .typed(liquid_locking_proxy::LiquidLockingProxy)
        .unbond(unbond_tokens)
        .run();

    world.check_account(OWNER_ADDRESS);
    world
        .check_account(FIRST_USER_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_1, 1_000)
        .dcdt_balance(WHITELIST_TOKEN_2, 700);

    world
        .check_account(SECOND_USER_ADDRESS)
        .dcdt_balance(BLACKLIST_TOKEN, 1_000)
        .dcdt_balance(WHITELIST_TOKEN_2, 200)
        .balance(1_000_000_000);

    world
        .check_account(LIQUID_STAKING_ADDRESS)
        .dcdt_balance(WHITELIST_TOKEN_2, 1_100)
        .check_storage("str:unbond_period", "10")
        .check_storage("str:token_whitelist.len", "2")
        .check_storage("str:token_whitelist.item|u32:1", "str:AAA-111111")
        .check_storage("str:token_whitelist.item|u32:2", "str:BBB-222222")
        .check_storage("str:token_whitelist.index|nested:str:AAA-111111", "1")
        .check_storage("str:token_whitelist.index|nested:str:BBB-222222", "2")
        .check_storage("str:locked_tokens|address:user2|str:.len", "1")
        .check_storage(
            "str:locked_tokens|address:user2|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user2|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage(
            "str:locked_token_amounts|address:user2|nested:str:BBB-222222",
            "800",
        )
        .check_storage("str:locked_tokens|address:user1|str:.len", "1")
        .check_storage(
            "str:locked_tokens|address:user1|str:.item|u32:1",
            "str:BBB-222222",
        )
        .check_storage(
            "str:locked_tokens|address:user1|str:.index|nested:str:BBB-222222",
            "1",
        )
        .check_storage(
            "str:locked_token_amounts|address:user1|nested:str:BBB-222222",
            "300",
        );
}
