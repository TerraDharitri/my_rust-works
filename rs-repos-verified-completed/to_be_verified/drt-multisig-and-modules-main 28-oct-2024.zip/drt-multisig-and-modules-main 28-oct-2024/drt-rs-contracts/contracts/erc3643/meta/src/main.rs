fn main() {
    dharitri_sc_meta_lib::cli_main::<erc3643::AbiProvider>();
}
