fn main() {
    dharitri_sc_meta::cli_main::<simple_lock_legacy::AbiProvider>();
}
