fn main() {
    dharitri_sc_meta::cli_main::<farm_staking_proxy_v_13::AbiProvider>();
}
