fn main() {
    dharitri_sc_meta::cli_main::<price_discovery::AbiProvider>();
}
