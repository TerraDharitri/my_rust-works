fn main() {
    dharitri_sc_meta::cli_main::<metabonding_staking::AbiProvider>();
}
