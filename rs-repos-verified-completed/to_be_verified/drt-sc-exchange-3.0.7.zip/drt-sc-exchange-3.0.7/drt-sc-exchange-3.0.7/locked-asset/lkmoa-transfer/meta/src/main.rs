fn main() {
    dharitri_sc_meta::cli_main::<lkmoa_transfer::AbiProvider>();
}
