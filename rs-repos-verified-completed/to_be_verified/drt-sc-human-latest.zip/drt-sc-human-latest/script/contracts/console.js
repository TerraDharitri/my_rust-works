global.setup = async (networkChoice) => {
    global.drtjs = require('@numbatnetwork/drtjs');
    let { drtSys, wallets } = await drtjs.setupInteractive(networkChoice);
    global.drtSys = drtSys;
    for (walletName in wallets) {
        global[walletName] = wallets[walletName];
    }
    console.log(`Add this to the config.env:\nNETWORK_PROVIDER=${networkChoice}`);
}

global.issueToken = async (
    owner,
    initialAmount,
    name = 'HumanToken',
    identifier = 'HMT',
    decimals = 18
) => {
    let unissuedToken = drtjs.createBalanceBuilder(new drtjs.Token({ identifier, name, decimals, type: drtjs.TokenType.Fungible }));
    global.humanToken = await drtSys.sender(owner).issueFungible(name, identifier, unissuedToken(initialAmount), decimals);
    console.log(`Add the token identifier to config.env:\nHUMAN_TOKEN_IDENTIFIER=${humanToken.getTokenIdentifier()}`);
}

global.recallToken = async (tokenIdentifier) => {
    global.humanToken = await drtSys.recallToken(tokenIdentifier);
}

global.deployJobTemplate = async (owner) => {
    let job = await drtSys.loadWrapper("job");
    await job.sender(owner).gas(130_000_000).call.deploy('-', owner, 0);
    console.log(`Add this to the config.env:\nJOB_TEMPLATE_ADDRESS=${job.getAddress().bech32()}`);
}

global.printKeys = (wallet) => {
    console.log(`public: "${wallet.address.bech32()}",`);
    console.log(`private: "${wallet.secretKey.toString('hex')}",`);
}

global.transferToken = async (from, to, amount) => {
    await drtSys.sender(from).value(humanToken(amount)).send(to);
}

global.checkBalance = async (wallet) => {
    await drtSys.getBalance(wallet, humanToken).then(drtjs.print);
}
