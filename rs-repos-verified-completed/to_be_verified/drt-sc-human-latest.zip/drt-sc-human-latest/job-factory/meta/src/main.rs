fn main() {
    dharitri_sc_meta::cli_main::<job_factory::AbiProvider>();
}
