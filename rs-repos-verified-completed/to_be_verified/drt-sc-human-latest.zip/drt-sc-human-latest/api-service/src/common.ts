import fetch from 'node-fetch';
import {
    Address,
    ContractWrapper,
    setupInteractive,
    SystemWrapper,
} from '@numbatnetwork/drtjs/out';
import { TestWallet } from '@numbatnetwork/drtjs/out/testutils';
import { GasPayerDto } from 'model/gasPayerDto';
import { AddressDto } from 'model/addressDto';
import { ApiConfigService } from './apiConfigService';
import { StorageService } from './storage.service';

export async function makeWallet(
    gasPayerDto: GasPayerDto,
    drtSys: SystemWrapper,
): Promise<TestWallet> {
    const wallet = new TestWallet(
        new Address(gasPayerDto.gasPayer),
        gasPayerDto.gasPayerPrivate,
        null,
        null,
    );
    await wallet.sync(drtSys.getProvider());
    return wallet;
}

export async function prepareContract(
    addressDto: AddressDto,
    drtSys: SystemWrapper,
    contract: ContractWrapper,
): Promise<void> {
    const wallet = await makeWallet(addressDto, drtSys);
    contract.address(addressDto.address).sender(wallet);
}

export async function loadContracts(config: ApiConfigService) {
    const { drtSys } = await setupInteractive(config.networkProvider);
    const jobContract = await drtSys.loadWrapper('../job');
    const factoryContract = await drtSys.loadWrapper('../job-factory');
    const humanToken = await drtSys.recallToken(config.humanTokenIdentifier);
    return { drtSys, jobContract, factoryContract, humanToken };
}

export async function getJsonFromUrl(url: string): Promise<any> {
    return await fetch(url).then((res) => res.json());
}

export async function uploadFromUrl(
    sourceUrl: string,
    pubKey: string,
    storage: StorageService,
): Promise<{ hash: string; url: string; json: any }> {
    const json = await getJsonFromUrl(sourceUrl);
    const jsonString = JSON.stringify(json);
    const { hash, key: url } = await storage.upload(jsonString, pubKey);
    return { hash, url, json };
}
