
export class StringDataResponse {
    data: string;
}

