
export class PollingUrlResponse {
    polling_url: string;
    polling_policy_seconds: number;
}

