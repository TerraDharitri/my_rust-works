
export class BoolDataResponse {
    success: boolean;
}

