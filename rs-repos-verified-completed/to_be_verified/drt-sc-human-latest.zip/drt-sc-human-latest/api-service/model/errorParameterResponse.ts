
export class ErrorParameterResponse {
    error: string;
    parameter_name: string;
}

