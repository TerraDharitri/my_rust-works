
export class JobListResponse {
    jobs: Array<string>;
}

