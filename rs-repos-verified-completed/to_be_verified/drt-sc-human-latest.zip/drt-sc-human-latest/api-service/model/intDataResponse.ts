
export class IntDataResponse {
    data: number;
}

