import { AddressDto } from "./addressDto";

export class FactoryGetBody extends AddressDto { }
