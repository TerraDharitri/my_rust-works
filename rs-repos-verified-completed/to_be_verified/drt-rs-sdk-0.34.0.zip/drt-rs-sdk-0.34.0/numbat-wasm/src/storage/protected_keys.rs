pub static NUMBAT_REWARD_KEY: &[u8] = b"NUMBATreward";
pub static NUMBAT_DCDT_LOCAL_ROLES_KEY: &[u8] = b"NUMBATroledcdt";
