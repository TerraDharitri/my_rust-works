mod properties;
mod system_sc_proxy;

pub use properties::*;
pub use system_sc_proxy::DCDTSystemSmartContractProxy;
