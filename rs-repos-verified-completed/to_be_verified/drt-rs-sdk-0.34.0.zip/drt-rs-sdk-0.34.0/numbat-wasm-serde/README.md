# numbat-wasm-serde

A serde-based serialization format for numbat-wasm, similat to bincode, but no_std.

Not currently in use, was replaced by a more lightweight serializer.
