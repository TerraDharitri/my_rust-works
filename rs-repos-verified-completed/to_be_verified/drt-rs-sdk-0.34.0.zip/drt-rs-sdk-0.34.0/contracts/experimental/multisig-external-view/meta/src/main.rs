fn main() {
    numbat_wasm_debug::meta::perform::<multisig_external_view::AbiProvider>();
}
