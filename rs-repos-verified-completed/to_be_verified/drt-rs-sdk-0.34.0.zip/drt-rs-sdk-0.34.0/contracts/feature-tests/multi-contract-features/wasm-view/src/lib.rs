////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::external_view_wasm_endpoints! {
    multi_contract_features
    (
        external_pure
        sample_value_external_get
        sample_value_external_set
    )
}

numbat_wasm_node::wasm_empty_callback! {}
