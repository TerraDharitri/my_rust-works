fn main() {
    numbat_wasm_debug::meta::perform::<multi_contract_features::AbiProvider>();
}
