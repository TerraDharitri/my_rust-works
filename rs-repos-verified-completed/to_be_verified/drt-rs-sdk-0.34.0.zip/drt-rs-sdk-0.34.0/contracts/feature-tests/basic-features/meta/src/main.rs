fn main() {
    numbat_wasm_debug::meta::perform::<basic_features::AbiProvider>();
}
