fn main() {
    numbat_wasm_debug::meta::perform::<abi_tester::AbiProvider>();
}
