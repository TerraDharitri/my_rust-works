fn main() {
    numbat_wasm_debug::meta::perform::<dcdt_system_sc_mock::AbiProvider>();
}
