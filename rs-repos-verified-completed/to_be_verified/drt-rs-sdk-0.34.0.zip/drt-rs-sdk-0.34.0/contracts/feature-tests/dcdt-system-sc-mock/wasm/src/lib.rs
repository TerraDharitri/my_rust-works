////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    dcdt_system_sc_mock
    (
        issue
        issueNonFungible
        issueSemiFungible
        registerAndSetAllRoles
        registerMetaDCDT
        setSpecialRole
    )
}

numbat_wasm_node::wasm_empty_callback! {}
