#[test]
fn issue_go() {
    numbat_wasm_debug::denali_go("denali/dcdt_system_sc.scen.json");
}
