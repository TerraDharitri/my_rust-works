fn main() {
    numbat_wasm_debug::meta::perform::<numbat_wasm_sc_dns::AbiProvider>();
}
