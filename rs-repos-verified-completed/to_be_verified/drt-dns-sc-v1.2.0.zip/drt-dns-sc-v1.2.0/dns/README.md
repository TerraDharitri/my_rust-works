# numbat-wasm-sc-dns

The Domain Name Service smart contract on the Numbat Network.

There are 256 instances of the DNS contract deployed on the mainnet. Each handles a part of the names.
The DNS contracts are the only ones allowed to set account usernames.
