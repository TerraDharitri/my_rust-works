#!/bin/sh

drtpy --verbose contract build dns
