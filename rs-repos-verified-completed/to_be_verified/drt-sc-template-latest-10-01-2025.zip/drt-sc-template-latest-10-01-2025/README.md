# Smart contract template

Template for creating smart contracts.

## Using the template

### clone or click `use this template` feature

# Never Sea Festival Smart Contract

You are the Never Sea Festival 2023 organizers and you decide to create the registration via blockchain.
Starting from this Smart Contract template you have to add more features to coordinate the event.

* Compile and deploy the Smart Contract template ===
* Modify the registration fee to enable Early Bird and Full price access ===
* Modify the registration endpoint to enable VIP access ===
* Create a feature to enable 50% discount vouchers for friends and partners ===
