#![no_std]

dharitri_sc::imports!();
dharitri_sc::derive_imports!();

pub mod unique_payments;

pub use unique_payments::*;
