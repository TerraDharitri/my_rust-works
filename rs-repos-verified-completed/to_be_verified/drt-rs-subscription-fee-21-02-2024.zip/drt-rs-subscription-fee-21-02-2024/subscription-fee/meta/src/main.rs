fn main() {
    dharitri_sc_meta::cli_main::<subscription_fee::AbiProvider>();
}
