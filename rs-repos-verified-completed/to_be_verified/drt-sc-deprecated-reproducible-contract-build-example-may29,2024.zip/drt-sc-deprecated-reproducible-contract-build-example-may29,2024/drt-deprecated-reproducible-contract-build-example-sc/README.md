# drt-reproducible-contract-build-example-sc

This repository has been deprecated.

Instead, please follow [docs.dharitri.org](https://docs.dharitri.org/developers/reproducible-contract-builds).
