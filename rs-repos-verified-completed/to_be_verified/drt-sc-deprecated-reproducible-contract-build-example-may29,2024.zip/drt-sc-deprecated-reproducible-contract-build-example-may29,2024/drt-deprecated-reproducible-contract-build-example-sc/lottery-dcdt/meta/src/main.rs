fn main() {
    dharitri_sc_meta::cli_main::<lottery_dcdt::AbiProvider>();
}
