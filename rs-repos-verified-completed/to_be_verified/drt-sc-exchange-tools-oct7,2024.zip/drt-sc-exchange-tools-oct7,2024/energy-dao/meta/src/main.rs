fn main() {
    dharitri_sc_meta::cli_main::<energy_dao::AbiProvider>();
}
