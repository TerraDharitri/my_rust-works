fn main() {
    numbat_wasm_debug::meta::perform::<ping_pong_rewa::AbiProvider>();
}
