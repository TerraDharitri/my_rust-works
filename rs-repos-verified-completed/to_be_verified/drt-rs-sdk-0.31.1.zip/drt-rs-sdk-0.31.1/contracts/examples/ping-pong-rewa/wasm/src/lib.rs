////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    ping_pong_rewa
    (
        getActivationTimestamp
        getDeadline
        getMaxFunds
        getPingAmount
        getUserAddresses
        getUserStatus
        ping
        pong
        pongAll
        pongAllLastUser
    )
}

numbat_wasm_node::wasm_empty_callback! {}
