////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    kitty_auction
    (
        callBack
        bid
        createAndAuctionGenZeroKitty
        createSaleAuction
        createSiringAuction
        endAuction
        getAuctionStatus
        getCurrentWinningBid
        isUpForAuction
        setKittyOwnershipContractAddress
    )
}
