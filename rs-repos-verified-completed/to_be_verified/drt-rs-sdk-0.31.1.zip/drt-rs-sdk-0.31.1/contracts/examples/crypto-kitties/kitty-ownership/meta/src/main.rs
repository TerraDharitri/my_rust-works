fn main() {
    numbat_wasm_debug::meta::perform::<kitty_ownership::AbiProvider>();
}
