////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    kitty_ownership
    (
        callBack
        allowAuctioning
        approve
        approveSiring
        approveSiringAndReturnKitty
        balanceOf
        birthFee
        breedWith
        canBreedWith
        claim
        createGenZeroKitty
        getKittyById
        giveBirth
        isPregnant
        isReadyToBreed
        ownerOf
        setGeneScienceContractAddress
        setKittyAuctionContractAddress
        tokensOfOwner
        totalSupply
        transfer
        transfer_from
    )
}
