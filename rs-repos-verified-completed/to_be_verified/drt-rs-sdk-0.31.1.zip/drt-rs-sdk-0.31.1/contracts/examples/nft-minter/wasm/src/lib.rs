////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    nft_minter
    (
        callBack
        buyNft
        claimRoyaltiesFromMarketplace
        createNft
        getNftPrice
        issueToken
        setLocalRoles
    )
}
