fn main() {
    numbat_wasm_debug::meta::perform::<nft_storage_prepay::AbiProvider>();
}
