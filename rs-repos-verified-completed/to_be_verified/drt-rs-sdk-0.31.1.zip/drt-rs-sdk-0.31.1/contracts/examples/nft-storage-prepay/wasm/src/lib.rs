////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    nft_storage_prepay
    (
        claim
        depositPaymentForStorage
        getCostForSize
        getCostPerByte
        getDepositAmount
        reserveFunds
        setCostPerByte
        withdraw
    )
}

numbat_wasm_node::wasm_empty_callback! {}
