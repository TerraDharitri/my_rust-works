fn main() {
    numbat_wasm_debug::meta::perform::<order_book_factory::AbiProvider>();
}
