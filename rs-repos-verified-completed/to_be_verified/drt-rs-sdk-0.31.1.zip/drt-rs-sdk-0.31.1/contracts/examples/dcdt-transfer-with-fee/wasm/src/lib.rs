////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    dcdt_transfer_with_fee
    (
        claimFees
        getPaidFees
        getTokenFee
        setExactValueFee
        setPercentageFee
        transfer
    )
}

numbat_wasm_node::wasm_empty_callback! {}
