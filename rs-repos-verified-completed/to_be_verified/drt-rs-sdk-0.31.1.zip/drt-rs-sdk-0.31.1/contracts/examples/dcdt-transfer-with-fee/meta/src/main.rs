fn main() {
    numbat_wasm_debug::meta::perform::<dcdt_transfer_with_fee::AbiProvider>();
}
