////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::external_view_wasm_endpoints! {
    multisig
    (
        getActionData
        getActionSignerCount
        getActionSigners
        getActionValidSignerCount
        getAllBoardMembers
        getAllProposers
        getPendingActionFullInfo
        userRole
    )
}

numbat_wasm_node::wasm_empty_callback! {}
