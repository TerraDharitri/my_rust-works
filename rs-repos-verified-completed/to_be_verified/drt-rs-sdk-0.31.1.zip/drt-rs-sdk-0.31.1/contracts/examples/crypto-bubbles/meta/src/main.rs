fn main() {
    numbat_wasm_debug::meta::perform::<crypto_bubbles::AbiProvider>();
}
