////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    crypto_bubbles
    (
        balanceOf
        joinGame
        rewardAndSendToWallet
        rewardWinner
        topUp
        withdraw
    )
}

numbat_wasm_node::wasm_empty_callback! {}
