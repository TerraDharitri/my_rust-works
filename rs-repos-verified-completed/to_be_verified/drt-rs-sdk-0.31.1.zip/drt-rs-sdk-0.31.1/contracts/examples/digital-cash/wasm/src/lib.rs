////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    digital_cash
    (
        amount
        claim
        deposit
        fund
        withdraw
    )
}

numbat_wasm_node::wasm_empty_callback! {}
