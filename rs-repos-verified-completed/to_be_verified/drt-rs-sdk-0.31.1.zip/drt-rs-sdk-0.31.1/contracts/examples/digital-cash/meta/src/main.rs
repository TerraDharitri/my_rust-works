fn main() {
    numbat_wasm_debug::meta::perform::<digital_cash::AbiProvider>();
}
