////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    rewa_dcdt_swap
    (
        callBack
        getLockedRewaBalance
        getWrappedRewaTokenIdentifier
        issueWrappedRewa
        setLocalRoles
        unwrapRewa
        wrapRewa
    )
}
