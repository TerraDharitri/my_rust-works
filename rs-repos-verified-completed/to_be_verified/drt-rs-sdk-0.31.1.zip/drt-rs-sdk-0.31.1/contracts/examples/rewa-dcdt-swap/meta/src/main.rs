fn main() {
    numbat_wasm_debug::meta::perform::<rewa_dcdt_swap::AbiProvider>();
}
