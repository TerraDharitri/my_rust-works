#[test]
fn unwrap_rewa_go() {
    numbat_wasm_debug::denali_go("denali/unwrap_rewa.scen.json");
}

#[test]
fn wrap_rewa_go() {
    numbat_wasm_debug::denali_go("denali/wrap_rewa.scen.json");
}
