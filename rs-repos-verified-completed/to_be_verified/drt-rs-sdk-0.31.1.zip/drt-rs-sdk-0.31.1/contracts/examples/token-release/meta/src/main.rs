fn main() {
    numbat_wasm_debug::meta::perform::<token_release::AbiProvider>();
}
