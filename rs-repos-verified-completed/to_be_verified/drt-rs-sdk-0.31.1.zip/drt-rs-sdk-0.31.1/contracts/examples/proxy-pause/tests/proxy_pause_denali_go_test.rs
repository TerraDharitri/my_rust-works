#[test]
fn pause_go() {
    numbat_wasm_debug::denali_go("denali/pause-and-unpause.scen.json");
}
