////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    proxy_pause
    (
        addContracts
        addOwners
        contracts
        owners
        pause
        removeContracts
        removeOwners
        unpause
    )
}

numbat_wasm_node::wasm_empty_callback! {}
