fn main() {
    numbat_wasm_debug::meta::perform::<proxy_pause::AbiProvider>();
}
