#[test]
fn adder_go() {
    numbat_wasm_debug::denali_go("denali/adder.scen.json");
}
