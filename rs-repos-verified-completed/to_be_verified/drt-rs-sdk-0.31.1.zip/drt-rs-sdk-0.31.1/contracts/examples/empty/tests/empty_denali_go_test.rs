#[test]
fn empty_go() {
    numbat_wasm_debug::denali_go("denali/empty.scen.json");
}
