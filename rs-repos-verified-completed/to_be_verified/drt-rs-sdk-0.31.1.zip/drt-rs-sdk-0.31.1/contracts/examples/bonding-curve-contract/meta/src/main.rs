fn main() {
    numbat_wasm_debug::meta::perform::<bonding_curve_contract::AbiProvider>();
}
