////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    crowdfunding_dcdt
    (
        claim
        fund
        getCrowdfundingTokenIdentifier
        getCurrentFunds
        getDeadline
        getDeposit
        getTarget
        status
    )
}

numbat_wasm_node::wasm_empty_callback! {}
