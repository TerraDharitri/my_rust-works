fn main() {
    numbat_wasm_debug::meta::perform::<crowdfunding_dcdt::AbiProvider>();
}
