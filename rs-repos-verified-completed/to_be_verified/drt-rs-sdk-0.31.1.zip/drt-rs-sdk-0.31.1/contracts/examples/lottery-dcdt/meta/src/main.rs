fn main() {
    numbat_wasm_debug::meta::perform::<lottery_dcdt::AbiProvider>();
}
