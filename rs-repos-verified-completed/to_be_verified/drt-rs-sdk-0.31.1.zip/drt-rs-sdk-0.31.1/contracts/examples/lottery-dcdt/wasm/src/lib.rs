////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    lottery_dcdt
    (
        buy_ticket
        createLotteryPool
        determine_winner
        getLotteryInfo
        getLotteryWhitelist
        start
        status
    )
}

numbat_wasm_node::wasm_empty_callback! {}
