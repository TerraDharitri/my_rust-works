#[test]
fn str_repeat_go() {
    numbat_wasm_debug::denali_go("denali/str_repeat.scen.json");
}
