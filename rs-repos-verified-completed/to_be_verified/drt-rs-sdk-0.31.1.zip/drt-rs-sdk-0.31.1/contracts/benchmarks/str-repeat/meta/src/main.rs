fn main() {
    numbat_wasm_debug::meta::perform::<str_repeat::AbiProvider>();
}
