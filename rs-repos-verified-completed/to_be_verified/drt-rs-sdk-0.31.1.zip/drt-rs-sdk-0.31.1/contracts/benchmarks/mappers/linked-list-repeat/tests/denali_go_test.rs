#[test]
fn linked_list_repeat_struct_go() {
    numbat_wasm_debug::denali_go("denali/linked_list_repeat_struct.scen.json");
}

#[test]
fn linked_list_repeat_go() {
    numbat_wasm_debug::denali_go("denali/linked_list_repeat.scen.json");
}
