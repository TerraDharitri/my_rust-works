fn main() {
    numbat_wasm_debug::meta::perform::<linked_list_repeat::AbiProvider>();
}
