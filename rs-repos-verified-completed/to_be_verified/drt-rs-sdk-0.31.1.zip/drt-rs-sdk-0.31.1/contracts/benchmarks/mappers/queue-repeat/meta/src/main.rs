fn main() {
    numbat_wasm_debug::meta::perform::<queue_repeat::AbiProvider>();
}
