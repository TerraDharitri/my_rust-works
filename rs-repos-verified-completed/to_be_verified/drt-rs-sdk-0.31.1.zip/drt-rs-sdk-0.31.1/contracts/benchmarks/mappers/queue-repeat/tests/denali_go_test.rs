#[test]
fn queue_repeat_go() {
    numbat_wasm_debug::denali_go("denali/queue_repeat.scen.json");
}
