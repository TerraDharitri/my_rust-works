fn main() {
    numbat_wasm_debug::meta::perform::<single_value_repeat::AbiProvider>();
}
