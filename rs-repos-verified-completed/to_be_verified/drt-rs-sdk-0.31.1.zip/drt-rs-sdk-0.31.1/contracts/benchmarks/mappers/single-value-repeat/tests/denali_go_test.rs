#[test]
fn single_value_repeat_struct_go() {
    numbat_wasm_debug::denali_go("denali/single_value_repeat_struct.scen.json");
}

#[test]
fn single_value_repeat_go() {
    numbat_wasm_debug::denali_go("denali/single_value_repeat.scen.json");
}
