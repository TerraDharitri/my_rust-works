#[test]
fn vec_repeat_struct_go() {
    numbat_wasm_debug::denali_go("denali/vec_repeat_struct.scen.json");
}

#[test]
fn vec_repeat_go() {
    numbat_wasm_debug::denali_go("denali/vec_repeat.scen.json");
}
