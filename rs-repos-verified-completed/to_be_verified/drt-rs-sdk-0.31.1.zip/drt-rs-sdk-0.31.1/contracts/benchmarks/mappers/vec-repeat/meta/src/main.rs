fn main() {
    numbat_wasm_debug::meta::perform::<vec_repeat::AbiProvider>();
}
