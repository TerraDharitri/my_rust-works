////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    vec_repeat
    (
        add
        add_struct
        bench
        bench_struct
        count
        count_struct
        remove
        remove_struct
    )
}

numbat_wasm_node::wasm_empty_callback! {}
