#[test]
fn map_repeat_struct_go() {
    numbat_wasm_debug::denali_go("denali/map_repeat_struct.scen.json");
}

#[test]
fn map_repeat_go() {
    numbat_wasm_debug::denali_go("denali/map_repeat.scen.json");
}
