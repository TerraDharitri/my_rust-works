////////////////////////////////////////////////////
////////////////// AUTO-GENERATED //////////////////
////////////////////////////////////////////////////

#![no_std]

numbat_wasm_node::wasm_endpoints! {
    map_repeat
    (
        add
        add_struct
        count
        count_struct
        remove
        remove_struct
    )
}

numbat_wasm_node::wasm_empty_callback! {}
