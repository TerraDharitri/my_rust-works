fn main() {
    numbat_wasm_debug::meta::perform::<map_repeat::AbiProvider>();
}
