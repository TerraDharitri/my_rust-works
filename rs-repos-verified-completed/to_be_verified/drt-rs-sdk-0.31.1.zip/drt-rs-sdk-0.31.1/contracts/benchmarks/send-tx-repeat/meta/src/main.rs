fn main() {
    numbat_wasm_debug::meta::perform::<send_tx_repeat::AbiProvider>();
}
