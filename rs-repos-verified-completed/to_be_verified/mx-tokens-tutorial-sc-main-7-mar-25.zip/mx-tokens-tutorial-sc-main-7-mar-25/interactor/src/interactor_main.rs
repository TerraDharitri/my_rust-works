
use dharitri_sc_snippets::imports::*;
use rust_interact::my_token_contract_cli;

#[tokio::main]
async fn main() {
    my_token_contract_cli().await;
}  

