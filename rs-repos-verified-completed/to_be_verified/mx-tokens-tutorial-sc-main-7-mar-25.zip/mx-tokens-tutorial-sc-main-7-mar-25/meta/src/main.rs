fn main() {
    dharitri_sc_meta_lib::cli_main::<my_token_contract::AbiProvider>();
}
