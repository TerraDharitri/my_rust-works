fn main() {
    numbat_wasm_debug::abi_json::print_abi::<flash_mint_provider::AbiProvider>();
}
