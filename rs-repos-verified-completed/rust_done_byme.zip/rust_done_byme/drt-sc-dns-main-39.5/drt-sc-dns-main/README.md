# drt-rs-sc-dns

Dharitri DNS smart contract, written in Rust.

You can also find a C version of the same contract.

## Build

`sc-meta all build`

It will produce `dns/output/dns.wasm`.

For more info, see [the tooling reference](https://docs.dharitri.org/developers/developer-reference/sc-meta) or [the build reference](https://docs.dharitri.org/developers/developer-reference/sc-build-reference).
