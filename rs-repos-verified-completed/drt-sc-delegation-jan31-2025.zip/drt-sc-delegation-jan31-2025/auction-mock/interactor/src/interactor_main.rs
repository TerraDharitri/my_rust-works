
use dharitri_sc_snippets::imports::*;
use rust_interact::auction_mock_cli;

#[tokio::main]
async fn main() {
    auction_mock_cli().await;
}  

