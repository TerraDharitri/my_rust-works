fn main() {
    dharitri_sc_meta::cli_main::<aggregator_mock::AbiProvider>();
}
