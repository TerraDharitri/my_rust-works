fn main() {
    dharitri_sc_meta::cli_main::<digital_cash::AbiProvider>();
}
