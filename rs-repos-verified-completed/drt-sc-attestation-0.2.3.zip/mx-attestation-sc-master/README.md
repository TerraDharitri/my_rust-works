# sc-attestation-rs
General attestation contract written in rust
