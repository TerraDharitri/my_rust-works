fn main() {
    dharitri_sc_meta_lib::cli_main::<farm_v13_locked_rewards::AbiProvider>();
}
