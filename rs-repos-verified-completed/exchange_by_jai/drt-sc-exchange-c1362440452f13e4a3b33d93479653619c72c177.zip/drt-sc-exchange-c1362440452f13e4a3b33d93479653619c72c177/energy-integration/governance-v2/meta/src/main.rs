fn main() {
    dharitri_sc_meta::cli_main::<governance_v2::AbiProvider>();
}
