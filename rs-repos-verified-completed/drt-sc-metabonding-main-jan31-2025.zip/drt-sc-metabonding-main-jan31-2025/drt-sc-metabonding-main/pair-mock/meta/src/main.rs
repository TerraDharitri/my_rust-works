fn main() {
    dharitri_sc_meta::cli_main::<pair_mock::AbiProvider>();
}
