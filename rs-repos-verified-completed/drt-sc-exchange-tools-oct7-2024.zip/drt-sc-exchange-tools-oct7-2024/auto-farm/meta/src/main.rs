fn main() {
    dharitri_sc_meta::cli_main::<auto_farm::AbiProvider>();
}
