fn main() {
    dharitri_sc_meta::cli_main::<locked_token_pos_creator::AbiProvider>();
}
